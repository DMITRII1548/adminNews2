import './bootstrap'

import './search'
import './share'
