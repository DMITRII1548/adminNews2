<?php $__env->startSection('content'); ?>
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1 class="m-0">Цвета секций Новость</h1>
            </div><!-- /.col -->
            <div class="col-sm-6">
              <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item active">Главная</li>
              </ol>
            </div><!-- /.col -->
          </div><!-- /.row -->
        </div><!-- /.container-fluid -->
      </div>
      <!-- /.content-header -->

      <!-- Main content -->
      <section class="content">
        <div class="container-fluid">
          <!-- Small boxes (Stat box) -->
          <div class="row">
            <form action="<?php echo e(route('admin.section.update')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('patch'); ?>
                <div class="form-group">
                    <input type="text" name="header" placeholder="Цвет меню (HEX)" class="form-control" value="<?php echo e($section->header); ?>" required>
                </div>
                <div class="form-group">
                    <input type="text" name="main" placeholder="Цвет главной части (HEX)" class="form-control" value="<?php echo e($section->main); ?>" required>
                </div>
                <div class="form-group">
                    <input type="text" name="footer" placeholder="Цвет подвала (HEX)" class="form-control" value="<?php echo e($section->footer); ?>" required>
                </div>

                <div class="form-group">
                    <button class="btn btn-primary" type="submit">Изменить</button>
                 </div>
            </form>
          </div>
          <!-- /.row -->

          <!-- /.row (main row) -->
        </div><!-- /.container-fluid -->
      </section>
      <!-- /.content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\domains\news2\resources\views/admin/section/edit.blade.php ENDPATH**/ ?>