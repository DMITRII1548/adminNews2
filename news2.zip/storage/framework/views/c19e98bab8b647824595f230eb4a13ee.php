<?php $__env->startSection('content'); ?>
<main class="main" style="background: <?php echo e(\App\Models\PageColor::first()->main); ?>;">
    <section class="heading">
        <a href="<?php echo e(route('news.show', $trend->id)); ?>"><img src="<?php echo e($trend->imageUrl); ?>" alt="" class="heading__img"></a>
        <div class="heading__info" style="width: 100%">
            <div class="heading__top">
                <h5>Trending</h5>
                <div class="heading__icons">
                    <img onclick="addLike(<?php echo e($trend->id); ?>)" src="<?php echo e(asset('/imgs/card/like.svg')); ?>" id="like-img-<?php echo e($trend->id); ?>">
                    <img src="<?php echo e(asset('/imgs/card/repost.svg')); ?>" alt="Поделиться">
                    <img src="<?php echo e(asset('/imgs/card/save.svg')); ?>" alt="Заметки">
                </div>
            </div>
            <div class="heading__middle">
                <h1><?php echo e($trend->title); ?></a></h1>
                <img id="like-img-<?php echo e($trend->id); ?>" src="<?php echo e(asset('/imgs/card/imgs/main.jpg')); ?>" alt="" class="heading__img--mobile">
                <p class="heading__text">
                   <?php echo e($trend->description); ?>

                </p>
            </div>
            <div class="heading__bottom">
                <span class="heading__publish-date">
                    <?php echo e($trend->date); ?>

                </span>
                <span class="heading__author">
                    <?php echo e($trend->author_name); ?>

                </span>
            </div>
        </div>
    </section>
    <section class="error-alert">
        <button class="error-alert__btn">Breaking News</button>
        <h3 class="error-alert__title">
            Kanye West says he's running for president in 2020.
        </h3>
    </section>
    <section class="cards">
        <div class="cards__nav">
            <h3 class="cards__title">News</h3>
            <img src="<?php echo e(asset('/imgs/card/nav.svg')); ?>" alt="Навигация" class="cards__nav-img">
        </div>
        <div class="cards__wrapper">
            <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card">
                    <a href="<?php echo e(route('news.show', $n->id)); ?>"><img src="<?php echo e($n->imageUrl); ?>" alt="Card" class="card__img"></a>
                    <div class="card__wrapper">
                        <h4 class="card__title"><?php echo e($n->title); ?></h4>
                        <p class="card__text"><?php echo e($n->description); ?></p>
                        <div class="card__info">
                            <span><?php echo e($n->date); ?></span>
                            <span>By <?php echo e($n->author_name); ?></span>
                        </div>
                        <ul class="card__actions">
                            <li class="card__action">
                                <img onclick="addLike(<?php echo e($n->id); ?>)" src="<?php echo e(asset('/imgs/card/like.svg')); ?>" alt="Like" id="like-img-<?php echo e($n->id); ?>">
                                <span class="card__count" id="news-<?php echo e($n->id); ?>" id="like-<?php echo e($n->id); ?>"><?php echo e($n->likes); ?></span>
                            </li>
                            <li class="card__action" id="share">
                                <img src="<?php echo e(asset('/imgs/card/repost.svg')); ?>" alt="Поделиться">
                                <span class="card__count"><?php echo e($n->reposts); ?></span>
                            </li>
                            <li class="card__action">
                                <img src="<?php echo e(asset('/imgs/card/save.svg')); ?>" alt="Сохранить">
                            </li>
                        </ul>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
    </section>
    <section class="slider">
        <div class="slider__title">
            <h4>Editor’s Picks</h4>
            <img src="<?php echo e(asset('/imgs/card/star.svg')); ?>" alt="Звезда">
        </div>
        <div class="slider__wrapper">
            <div class="slider__items">
                <?php $__currentLoopData = $lastUpdated; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('news.show', $item->id)); ?>" class="slider-card">
                        <img src="<?php echo e($item->imageUrl); ?>" alt="" class="slider-card__img">
                    </a>
                        <h5 class="slider-card__title--mobile">
                           <?php echo e($item->title); ?>

                        </h5>
                        <div class="slider-card__wrapper">
                            <h4 class="slider-card__title"><?php echo e($item->title); ?></h4>
                            <p class="slider-card__text">
                                <?php echo e($item->description); ?>

                            </p>
                        </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
            <nav class="slider__nav">
                <svg xmlns="http://www.w3.org/2000/svg" width="121" height="4" viewBox="0 0 121 4" fill="none">
                    <path opacity="0.2" d="M0 0H15V4H0V0Z" fill="#EE6400"/>
                    <path d="M32 0H57V4H32V0Z" fill="#EE6400"/>
                    <path opacity="0.2" d="M74 0H89V4H74V0Z" fill="#EE6400"/>
                    <path opacity="0.2" d="M106 0H121V4H106V0Z" fill="#EE6400"/>
                </svg>
            </nav>


        </div>
    </section>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\domains\news2\resources\views/news/index.blade.php ENDPATH**/ ?>