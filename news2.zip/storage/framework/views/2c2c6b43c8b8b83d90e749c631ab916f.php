<?php $__env->startSection('content'); ?>
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1 class="m-0">Изменеить аккаунт</h1>
            </div><!-- /.col -->
            <div class="col-sm-6">
              <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item active">Главная</li>
              </ol>
            </div><!-- /.col -->
          </div><!-- /.row -->
        </div><!-- /.container-fluid -->
      </div>
      <!-- /.content-header -->

      <!-- Main content -->
      <section class="content">
        <div class="container-fluid">
          <!-- Small boxes (Stat box) -->
          <div class="row">
            <form action="<?php echo e(route('user.update')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('patch'); ?>
                <div class="form-group">
                    <input type="email" name="email" placeholder="E-mail" class="form-control" value="<?php echo e($user->email); ?>" required>
                </div>
                <div class="form-group">
                    <input type="password" name="new_password" placeholder="Новый пароль" class="form-control" required>
                </div>
                <div class="form-group">
                    <input type="password" name="old_password" placeholder="Старый пароль" class="form-control" required>
                </div>
                <div class="form-group">
                    <button class="btn btn-primary" type="submit">Изменить</button>
                 </div>
            </form>
          </div>
          <!-- /.row -->

          <!-- /.row (main row) -->
        </div><!-- /.container-fluid -->
      </section>
      <!-- /.content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\domains\news2\resources\views/user/edit.blade.php ENDPATH**/ ?>